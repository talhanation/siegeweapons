package com.talhanation.siegeweapons.entities;

import com.talhanation.siegeweapons.ModTexts;
import com.talhanation.siegeweapons.init.ModMenus;
import com.talhanation.siegeweapons.math.Kalkuel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.Comparator;

public class SmallHorseCartEntity extends AbstractInventoryVehicleEntity {

    private static final float HORSE_DISTANCE = 2.1F;
    private static final int INVENTORY_SIZE = 54;
    private static final int INVENTORY_COLUMNS = 9;

    public SmallHorseCartEntity(EntityType<? extends AbstractInventoryVehicleEntity> entityType, Level world) {
        super(entityType, world);
    }

    ///////////////////////////////////TICK/////////////////////////////////////////

    @Override
    public void tick() {
        super.tick();
        if (!getCommandSenderWorld().isClientSide()) {
            // Re-enforce NoAI on attached horse each tick to survive edge cases (e.g. chunk reload)
            AbstractHorse horse = getAttachedHorse();
            if (horse != null && !horse.isNoAi()) {
                horse.setNoAi(true);
            }
        }
    }

    ////////////////////////////////////CONTROL////////////////////////////////////

    /**
     * Overrides the base control logic:
     * - Speed only changes when forward/backward is pressed (persistent speed, no auto-deceleration)
     * - Steering: driver's yRot → horse's yRot → cart's yRot
     * - No horse = no movement
     */
    @Override
    public void control(Entity driver, float xRot, float yRot) {
        if (driver == null || !hasAttachedHorse()) {
            // Very slight deceleration when no driver or no horse
            setSpeed(Kalkuel.subtractToZero(getSpeed(), 0.002F));
            setForward(false);
            setBackward(false);
            setDeltaMovement(
                    Kalkuel.calculateMotionX(getSpeed(), this.getYRot()),
                    getDeltaMovement().y,
                    Kalkuel.calculateMotionZ(getSpeed(), this.getYRot())
            );
            return;
        }

        float maxSpeed = getMaxSpeedInKmH() / (60F * 1.15F);
        float speed = getSpeed(); // speed persists - no automatic deceleration while driving

        if (isForward()) {
            speed = Math.min(speed + 0.008F, maxSpeed);
        }

        if (isBackward()) {
            speed = Math.max(speed - 0.006F, 0F); // horse carts don't reverse
        }

        setSpeed(speed);

        // Steering: horse yRot follows the driver's look direction
        AbstractHorse horse = getAttachedHorse();
        if (horse != null) {
            horse.setYRot(driver.getYRot());
            horse.yHeadRot = driver.getYRot();
            horse.yBodyRot = driver.getYRot();
            horse.setXRot(0F);
        }

        // Cart yRot follows horse direction (forward vector always points toward horse)
        float targetYRot = horse != null ? horse.getYRot() : this.getYRot();
        this.setYRot(targetYRot);
        this.setXRot(0F);

        setDeltaMovement(
                Kalkuel.calculateMotionX(getSpeed(), this.getYRot()),
                getDeltaMovement().y,
                Kalkuel.calculateMotionZ(getSpeed(), this.getYRot())
        );
    }

    ////////////////////////////////////PASSENGERS////////////////////////////////////

    /**
     * Returns the controlling passenger (always the Player, never the horse).
     */
    @Override
    @Nullable
    public LivingEntity getControllingPassenger() {
        for (Entity passenger : getPassengers()) {
            if (passenger instanceof Player player) return player;
        }
        return null;
    }

    @Override
    protected boolean canAddPassenger(@NotNull Entity entity) {
        if (entity instanceof AbstractHorse) {
            return !hasAttachedHorse();
        }
        if (entity instanceof Player) {
            return getPassengers().stream().noneMatch(e -> e instanceof Player);
        }
        return false;
    }

    @Override
    protected void positionRider(@NotNull Entity rider, @NotNull MoveFunction moveFunction) {
        if (!this.hasPassenger(rider)) return;

        if (rider instanceof AbstractHorse) {
            // Horse is positioned in front of the cart
            double frontX = Kalkuel.calculateMotionX(HORSE_DISTANCE, this.getYRot());
            double frontZ = Kalkuel.calculateMotionZ(HORSE_DISTANCE, this.getYRot());
            moveFunction.accept(rider, this.getX() + frontX, this.getY(), this.getZ() + frontZ);

        } else {
            // Player (or other entity) sits on top of the cart, slightly behind center
            double riderX = Kalkuel.calculateMotionX(-0.4F, this.getYRot());
            double riderZ = Kalkuel.calculateMotionZ(-0.4F, this.getYRot());
            double riderY = this.getY() + this.getPassengersRidingOffset() + rider.getMyRidingOffset();
            moveFunction.accept(rider, this.getX() + riderX, riderY, this.getZ() + riderZ);
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(@NotNull LivingEntity passenger) {
        // Dismount to the side of the cart
        double sideX = Kalkuel.calculateMotionX(1.0F, this.getYRot() + 90F);
        double sideZ = Kalkuel.calculateMotionZ(1.0F, this.getYRot() + 90F);
        return new Vec3(this.getX() + sideX, this.getY(), this.getZ() + sideZ);
    }

    ////////////////////////////////////INTERACTION////////////////////////////////////

    @Override
    public InteractionResult interact(Player player, InteractionHand interactionHand) {
        if (this.itemInteraction(player, interactionHand)) return InteractionResult.SUCCESS;

        if (!this.getCommandSenderWorld().isClientSide()) {
            if (player.isSecondaryUseActive()) {
                if (hasAttachedHorse()) {
                    // Crouch + right-click: detach horse
                    detachHorse();
                    player.displayClientMessage(Component.translatable("entity.siegeweapons.small_horse_cart.horse_detached"), true);
                } else {
                    // Crouch + right-click with no horse: open inventory
                    this.openGUI(player);
                }
                return InteractionResult.SUCCESS;
            }

            // Right-click (not crouching): try to attach a nearby horse if none attached
            if (!hasAttachedHorse()) {
                AbstractHorse nearestHorse = findNearestHorse(3.5D);
                if (nearestHorse != null) {
                    attachHorse(nearestHorse);
                    player.displayClientMessage(Component.translatable("entity.siegeweapons.small_horse_cart.horse_attached"), true);
                    return InteractionResult.SUCCESS;
                }
            }

            // Try to ride the cart
            if (getPassengers().stream().noneMatch(e -> e instanceof Player)) {
                return this.tryRiding(player) ? InteractionResult.SUCCESS : InteractionResult.PASS;
            }
        }

        return InteractionResult.PASS;
    }

    ////////////////////////////////////HORSE MANAGEMENT////////////////////////////////////

    @Nullable
    public AbstractHorse getAttachedHorse() {
        for (Entity passenger : getPassengers()) {
            if (passenger instanceof AbstractHorse horse) return horse;
        }
        return null;
    }

    public boolean hasAttachedHorse() {
        return getAttachedHorse() != null;
    }

    private void attachHorse(AbstractHorse horse) {
        horse.setNoAi(true);
        horse.startRiding(this);
    }

    public void detachHorse() {
        AbstractHorse horse = getAttachedHorse();
        if (horse == null) return;

        horse.stopRiding();
        horse.setNoAi(false);

        // Place the horse next to the cart so it doesn't clip inside
        double sideX = Kalkuel.calculateMotionX(-1.5F, this.getYRot() + 90F);
        double sideZ = Kalkuel.calculateMotionZ(-1.5F, this.getYRot() + 90F);
        horse.setPos(this.getX() + sideX, this.getY(), this.getZ() + sideZ);
        horse.setYRot(this.getYRot());
    }

    @Nullable
    private AbstractHorse findNearestHorse(double radius) {
        return this.getCommandSenderWorld()
                .getEntitiesOfClass(AbstractHorse.class,
                        this.getBoundingBox().inflate(radius),
                        h -> h.isAlive() && !h.isVehicle())
                .stream()
                .min(Comparator.comparingDouble(h -> h.distanceToSqr(this)))
                .orElse(null);
    }

    ////////////////////////////////////INVENTORY////////////////////////////////////

    @Override
    public int getInventorySize() {
        return INVENTORY_SIZE;
    }

    @Override
    public int getInventoryColumns() {
        return INVENTORY_COLUMNS;
    }

    @Override
    public void openGUI(Player player) {
        if (!getCommandSenderWorld().isClientSide() && player instanceof ServerPlayer serverPlayer) {
            NetworkHooks.openScreen(
                    serverPlayer,
                    new SimpleMenuProvider(
                            (id, inv, p) -> new com.talhanation.siegeweapons.inventory.SmallHorseCartMenu(id, this, inv),
                            this.getDisplayName()
                    ),
                    buf -> buf.writeUUID(this.getUUID())
            );
        }
    }

    ////////////////////////////////////DATA////////////////////////////////////

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag compoundTag) {
        super.addAdditionalSaveData(compoundTag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag compoundTag) {
        super.readAdditionalSaveData(compoundTag);
    }

    ////////////////////////////////////ABSTRACT IMPL////////////////////////////////////

    @Override
    public Vec3 getDriverPosition() {
        double riderX = Kalkuel.calculateMotionX(-0.4F, this.getYRot());
        double riderZ = Kalkuel.calculateMotionZ(-0.4F, this.getYRot());
        return new Vec3(riderX, 0.0D, riderZ);
    }

    @Override
    public int getMaxPassengerSize() {
        return 2; // player + horse
    }

    @Override
    public int getMaxSpeedInKmH() {
        return 12;
    }

    @Override
    public double getMaxHealth() {
        return 150;
    }

    @Override
    public Component getVehicleTypeName() {
        return ModTexts.SMALL_HORSE_CART;
    }
}
